# Licenses and provenance

## 3D dice renderer
The dice renderer is from the user's TableGate repository (also present in KillerInTheKeep), based on an MIT-licensed dice renderer. The user-supplied repository records this MIT notice:

MIT License — Copyright (c) 2022 dice authors

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to inclusion of the copyright and permission notice. THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.

The bundled Three.js and Cannon.js are MIT-licensed dependencies. Retain upstream notices where redistributed.

## Sound files
- audio/character-dice.wav: KillerInTheKeep assets/audio/dice_character_quiet.wav
- audio/monster-dice.wav: KillerInTheKeep assets/audio/dice_monster_quiet.wav
  The repository states these two quiet WAVs were procedurally synthesized specifically for its production package and not sampled from third-party commercial recordings.
- audio/tablegate-classic.mp3: TableGate assets/audio/sessions/dice-roller/nc93322.mp3
  The provided repository does not establish independent sound licensing for this particular MP3. Verify its rights before distributing beyond your own projects, or remove it from this package.

## CSS designs
The nine named character/monster palettes are transcribed from KillerInTheKeep json/runtime/dice-assignments.json; the TableGate Cyan palette is taken from the 3D renderer's default. The minimal standalone layout CSS is new adaptation code.
