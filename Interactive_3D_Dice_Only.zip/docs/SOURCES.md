# Sources used

- https://github.com/tyrannosaurusdm92/TableGate
  - js/sessions/dice-roller/dice.js (single shared 3D dice renderer)
  - js/sessions/dice-roller/vendor/{three-min.js,cannon-min.js,teal.js}
  - assets/audio/sessions/dice-roller/nc93322.mp3
  - docs/github/licenses/source-code-session-dice-prior-reference-docs-licenses.md
- https://github.com/tyrannosaurusdm92/KillerInTheKeep
  - json/runtime/dice-assignments.json (nine character/monster color designs)
  - assets/audio/dice_character_quiet.wav
  - assets/audio/dice_monster_quiet.wav
  - docs/licenses/AUDIO_LICENSES.md
  - docs/licenses/DICE_RENDERER_AND_SRD_LICENSES.md

Duplicated renderers were deduplicated in favor of TableGate's copy.
The seven listed dice sizes have source-backed 3D geometry.
No gameplay systems, dice rules, score calculations or proprietary game databases are carried into this standalone presentation.
