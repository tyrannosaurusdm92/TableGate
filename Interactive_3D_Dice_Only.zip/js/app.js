"use strict";
/* Standalone presentation only. No game rules, modifiers, totals, sheets or systems. */
(function(){
  var TYPES=["d4","d6","d8","d10","d12","d20","d100"];
  var DESIGNS=["tablegate-cyan","daltu-yellow-green","noldrack-yellow-gold","eilvyre-navy","korbin-lava-red","jock-hot-pink","xun-amethyst","gunnus-black-cyan","monk-aged-copper","monster-brown"];
  var NAMES=["TableGate Cyan","Daltu Yellow-Green","Noldrack Yellow-Gold","Eilvyre Navy","Korbin Lava Red","Jock Hot Pink","Xun Amethyst","Gunnus Black + Cyan","Monk Aged Copper","Monster Brown"];
  var DEFAULTS=["daltu-yellow-green","noldrack-yellow-gold","eilvyre-navy","korbin-lava-red","jock-hot-pink","xun-amethyst","gunnus-black-cyan","monk-aged-copper"];
  var AUDIO={character:"audio/character-dice.wav",monster:"audio/monster-dice.wav",tablegate:"audio/tablegate-classic.mp3"};
  var stage=document.getElementById("stage"),buttons=[].slice.call(document.querySelectorAll("[data-die]"));
  var designInput=document.getElementById("design"),soundInput=document.getElementById("sound"),message=document.getElementById("message"),rollButton=document.getElementById("roll");
  var selected="all",busy=false,box=null;
  function palette(slug){
    var node=document.createElement("div");node.className="palette";node.setAttribute("data-design",slug);
    document.body.appendChild(node);
    var style=getComputedStyle(node);
    function v(key){return style.getPropertyValue("--die-"+key).trim();}
    var theme={slug:slug,name:NAMES[DESIGNS.indexOf(slug)]||slug,description:"CSS-based dice finish",
      base:v("base"),base2:v("base2"),ink:v("ink"),edge:v("edge"),glow:v("glow")};
    node.remove();return theme;
  }
  var skin=Object.create(null);
  DESIGNS.forEach(function(name){skin[name]=palette(name);});
  DESIGNS.forEach(function(name,i){var option=document.createElement("option");option.value=name;option.textContent=NAMES[i];designInput.appendChild(option);});
  function audioSource(){
    var kind=soundInput.value;
    if(kind==="muted")return [];
    if(kind==="auto")kind=(designInput.value==="monster-brown"?"monster":designInput.value==="tablegate-cyan"?"tablegate":"character");
    return [{url:AUDIO[kind]||AUDIO.character}];
  }
  function selectedTypes(){
    if(selected==="all")return ["d4","d6","d8","d10","d12","d20","d100","d10"];
    if(selected==="d100")return ["d100","d10"];
    return [selected];
  }
  function chooseStyle(types){
    var chosen=designInput.value,keys;
    if(chosen==="mixed"){
      keys=selected==="all"?DEFAULTS: selected==="d100"?DEFAULTS.slice(6,8):[DEFAULTS[TYPES.indexOf(selected)]];
    }else keys=types.map(function(){return chosen;});
    return keys.map(function(key){return skin[key];});
  }
  function setChoice(type){
    selected=type;
    buttons.forEach(function(button){var active=button.dataset.die===type;button.classList.toggle("active",active);button.setAttribute("aria-pressed",String(active));});
  }
  function finish(){
    busy=false;rollButton.disabled=false;
    message.textContent="";
  }
  function roll(silent){
    if(!box||busy)return;
    var types=selectedTypes(),styles=chooseStyle(types),notation=types.map(function(t){return "1"+t;}).join("+");
    DICE.set_theme_pool(styles);
    if(typeof DICE.set_theme_sequence==="function")DICE.set_theme_sequence(styles);
    DICE.set_sound_pool(silent?[]:audioSource());
    box.setDice(notation);
    busy=true;rollButton.disabled=true;
    message.textContent="";
    try{box.start_throw(function(){return null;},finish);}catch(error){finish();message.textContent="3D animation unavailable: "+String(error.message||error);}
  }
  if(!window.DICE||!window.THREE||!window.CANNON||!window.$t){message.textContent="A local 3D renderer file is missing.";rollButton.disabled=true;return;}
  try{
    box=new DICE.dice_box(stage);
  }catch(error){message.textContent="WebGL is required to display the 3D dice.";rollButton.disabled=true;return;}
  setChoice("all");
  buttons.forEach(function(button){button.addEventListener("click",function(){setChoice(button.dataset.die);roll(false);});});
  rollButton.addEventListener("click",function(){roll(false);});
  designInput.addEventListener("change",function(){roll(false);});
  soundInput.addEventListener("change",function(){});
  box.bind_swipe(stage,function(){return null;},finish);
  if(window.ResizeObserver){new ResizeObserver(function(){try{if(box&&!busy)box.reinit(stage);}catch(_){}}).observe(stage);}
  else window.addEventListener("resize",function(){if(box&&!busy)box.reinit(stage);});
  window.addEventListener("keydown",function(event){
    if(event.target&&["SELECT","BUTTON","INPUT"].indexOf(event.target.tagName)!==-1)return;
    if(event.code==="Space"||event.code==="Enter"){event.preventDefault();roll(false);}
  });
  window.StandaloneDice={roll:function(type){if(type&&TYPES.concat(["all"]).indexOf(type)!==-1)setChoice(type);roll(false);},
    setDesign:function(slug){if(slug==="mixed"||DESIGNS.indexOf(slug)>=0)designInput.value=slug;},
    setSound:function(name){if(["auto","character","monster","tablegate","muted"].indexOf(name)>=0)soundInput.value=name;}};
  requestAnimationFrame(function(){roll(true);});
}());
